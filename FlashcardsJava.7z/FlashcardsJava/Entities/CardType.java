package Entities;

public enum CardType {
    DEFINICAO("Definição de um conceito"),
    FORMULA("Uma fórmula matemática ou química"),
    EXEMPLO("Um exemplo prático"),
    PERGUNTA_RESPOSTA("Pergunta e reposta para estudo");

    private final String descricao;

    CardType(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }

}
