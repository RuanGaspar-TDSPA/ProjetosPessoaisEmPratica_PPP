package Entities;
import java.util.ArrayList;
import java.util.List;

public class Materia {
    private String nome;
    private List<Card> flashcards;

    public Materia(String nome) {
        this.nome = nome;
        this.flashcards = new ArrayList<>();
    }
    public void adicionarCard(Card card) {
        flashcards.add(card);
    }
    public String getNome() {
        return nome;
    }
    public void exibirFlashcards() {
        for (Card card : flashcards) {
            card.exibirCard();
        }
    }
}
