package Entities;
import Entities.Card;
import Entities.Materia;
public class Card {
    private String titulo;
    private String descricao;
    private String pergunta;
    private String resposta;
    private CardType tipo;
    private Materia materia;

    public Card(String titulo, String descricao, String resposta, CardType tipo, Materia materia) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.resposta = resposta;
        this.tipo = tipo;
        this.materia = materia;
    }
    public void exibirCard() {
        System.out.println("Titulo: " + titulo);
        System.out.println("Descrição: ");
        System.out.println("Resposta: " + resposta);
        System.out.println("Tipo: " + tipo);
        System.out.println("Matéria: " + materia.getNome());
        System.out.println("------------------------------");
    }

}
