package Entities;
import java.util.ArrayList;
import java.util.List;

public class Baralho {
    private String nome;
    private List<Materia> materias;

    public Baralho(String nome){
        this.nome = nome;
        this.materias = new ArrayList<>();
    }
    public void adicionarMateria(Materia materia){
        this.nome = nome;
        this.materias = new ArrayList<>();
    }
    public void exibirMaterias(){
        for (Materia materia : materias) {
            System.out.println("Matéria " + materia.getNome());
        }

    }
    public void exibirTodosFlashcards(){
        for (Materia materia : materias) {
            materia.exibirFlashcards();
        }
    }
}
