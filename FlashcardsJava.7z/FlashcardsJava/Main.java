import java.util.Scanner;
import Entities.Baralho;
import Entities.Card;
import Entities.CardType;
import Entities.Materia;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        //Criando barlaho de Ciências da Natureza
        Baralho baralho = new Baralho("Ciências da Natureza");
        // Criando uma nova matéria
        System.out.println("Digite o nome da matéria: ");
        String nomeMateria = sc.nextLine();
        Materia materia = new Materia(nomeMateria);
        // Adicionar matéria ao baralho
        baralho.adicionarMateria(materia);

        // Criando um novo card
        System.out.println("Digite o nome do card: ");
        String titulo = sc.nextLine();

        System.out.println("Digite a descrição do card: ");
        String descricao = sc.nextLine();

        System.out.println("Digite a resposta do card: ");
        String resposta = sc.nextLine();

        System.out.println("Escolha o tipo de card: ");
        System.out.println("1.DEFINICAO");
        System.out.println("2. FORMULA");
        System.out.println("3. EXEMPLO");
        System.out.println("4. PERGUNTA_RESPOSTA");

        int tipoEscolhido = sc.nextInt();
        CardType tipo = CardType.DEFINICAO;
        switch (tipoEscolhido) {
            case 1:
                tipo = CardType.DEFINICAO;
                break;
            case 2:
                tipo = CardType.FORMULA;
                break;
            case 3:
                tipo = CardType.EXEMPLO;
                break;
            case 4:
                tipo = CardType.PERGUNTA_RESPOSTA;
                break;
            default:
                System.out.println("Opção inválida. Tipo de card padrão: DEFINICAO.");
        }
        // Criando o card
        Card card = new Card(titulo, descricao, resposta, tipo, materia);

        // Adicionando o card à matéria
        materia.adicionarCard(card);

        // Exibindo conteúdos
        System.out.println("\n-- Baralho Atualizado --");
        baralho.exibirMaterias();
        baralho.exibirTodosFlashcards();

        sc.close();

        // Criando Matérias
        Materia biologia = new Materia("Biologia");
        Materia quimica = new Materia("Química");
        Materia fisica = new Materia("Física");

        // Adicionando Matérias ao Baralho
        baralho.adicionarMateria(fisica);
        baralho.adicionarMateria(quimica);

        // Criando cards
    Card card1 = new Card("Velocidade Média","Como calcular a velocidade média de um corpo?","V = ΔS / ΔT", CardType.FORMULA, fisica);
    Card card2 = new Card("Ligação Iônica", "O que caracteriza uma ligação iônica?", "Transferência de elétrons", CardType.DEFINICAO, quimica);

        // Adicionando cards às matérias
        fisica.adicionarCard(card1);
        quimica.adicionarCard(card2);

        // Exibindo os conteúdos
        baralho.exibirMaterias();
        baralho.exibirTodosFlashcards();
    }
}
